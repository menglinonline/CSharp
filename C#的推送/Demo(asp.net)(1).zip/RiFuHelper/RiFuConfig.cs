﻿namespace Demo.RiFuHelper
{
    public class RiFuConfig
    {
        /// <summary>
        /// 授权密钥
        /// </summary>
       public const string Key = "aed1233";
    }
}